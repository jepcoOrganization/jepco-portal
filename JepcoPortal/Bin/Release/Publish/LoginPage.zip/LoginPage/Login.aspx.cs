﻿using SiteWare.Domain.Domains;
using SiteWare.Entity.Common.Entities;
using SiteWare.Entity.Common.Enums;
using SiteWare.Entity.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using SiteWare.DataAccess.Repositories;
using HtmlAgilityPack;
using System.Web.Services;
using Siteware.Entity.Entities;
using Siteware.Domain.Domains;
using Newtonsoft.Json.Linq;




using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Web.Script.Serialization;
using System.Net;
using System.IO;
using Newtonsoft.Json;

public partial class LoginPage_Login : SiteBasePage
{
    public DateTime currentDate = DateTime.Now;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            

            //if (SessionManager.GetInstance.Users != null)
            //{

            //    if (RouteData.Values["language"] == null)
            //    {
            //        //Response.Redirect("ar/Home");
            //    }
            //}
            FillFooterNavigation();
           // FillLink();
        }
    }

    protected async void lnkSubmitFrm_Click(object sender, EventArgs e)
    {
        try
        {
           
            bool _isValEmail = false;
            //ResultEntity<ContactUsFormEntity> result = new ResultEntity<ContactUsFormEntity>();
            //ContactUsFormEntity entity = new ContactUsFormEntity();
            
            //entity.Email = txtEmail.Text;
           
            if (!string.IsNullOrEmpty(txtEmail.Text))
            {
                Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                Match match = regex.Match(txtEmail.Text);
                if (match.Success)
                {
                    _isValEmail = true;
                }
                else
                    _isValEmail = false;
            }
            if ( _isValEmail )
            {
                string Email = string.Empty;
                Email = txtEmail.Text;
                string Password = string.Empty;
                Password = txtPassword.Text;
                ResultEntity<Plugin_ServiceUserEntity> Result = await Plugin_ServiceUserDomain.CheckUserLogin(Email, Password);
                if (Result.Status == ErrorEnums.Success)
                {
                    //imgSuccessLogin.Visible = true;
                    if (Result.Entity.IsPublished == true)
                    {

                        long UserId = Result.Entity.ID;

                        ResultList<MobileRegistationEntity> MobileRegistrationResult = new ResultList<MobileRegistationEntity>();

                        MobileRegistrationResult = await MobileRegistationDomain.GetAll();
                        if (MobileRegistrationResult.Status == ErrorEnums.Success)
                        {
                            var GetMobileVerifyed = MobileRegistrationResult.List.Where(s => s.MobileNumber == Result.Entity.MobileNumber && s.ServiceUserID == UserId).ToList();

                            if (GetMobileVerifyed.Count > 0)
                            {
                                Boolean isRegisterd = GetMobileVerifyed[0].IsVerify;

                                if (isRegisterd == true)
                                {
                                    SessionManager.GetInstance.Users = Result.Entity;
                                    Response.Redirect("/ar/Home", false);
                                    //lblUserName.Text = Result.Entity.FirstName;
                                    //lblUserLastName.Text = Result.Entity.FamilyName;
                                    //lblUserAddress.Text = Result.Entity.Address;
                                    //lblUSerEmail.Text = Result.Entity.Email;
                                    //lblUSerMobile.Text = Result.Entity.MobileNumber;
                                    //hdnmobileno.Value = Result.Entity.MobileNumber;
                                    //lblUSerRegiDate.Text = Result.Entity.PublishDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                                }
                                else
                                {

                                    //#region--> New API
                                    ////*************************---New API Integration---------- ****************************************************

                                    ////----------------------------------------- Latest Code --------------------------------------
                                    //var getSMSCred = await GetAccessToken();
                                    //Page.Response.Write("<script>console.log(' Call For OTP ');</script>");
                                    //string smsException = string.Empty;

                                    //string dyna_otp = Generatenumber();
                                    //if (!string.IsNullOrEmpty(getSMSCred.SenderID) && !string.IsNullOrEmpty(getSMSCred.AccessToken))
                                    //{
                                    //    List<string> MobileNumber = new List<string>();
                                    //    MobileNumber.Add(Result.Entity.MobileNumber);
                                    //    var Body = new
                                    //    {


                                    //        service_type = "bulk_sms",
                                    //        recipient_numbers_type = "single_numbers",
                                    //        phone_numbers = MobileNumber.ToArray(),

                                    //        content = "اهلا وسهلا بكم في البوابة الالكترونية لشركة الكهرباء رقم التعريف الخاص بك هو " + dyna_otp,
                                    //        sender_id = "JEPCO"

                                    //    };
                                    //    Page.Response.Write("<script>console.log('Mobile No : " + Result.Entity.MobileNumber + "');</script>");
                                    //    string inputJson = (new JavaScriptSerializer()).Serialize(Body);
                                    //    HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(new Uri(ConfigurationManager.AppSettings["SMSURL"].ToString()));
                                    //    httpRequest.ContentType = "application/json";
                                    //    httpRequest.Method = "POST";
                                    //    httpRequest.Headers.Add("integration_token", getSMSCred.AccessToken);

                                    //    byte[] bytes = Encoding.UTF8.GetBytes(inputJson);
                                    //    using (Stream stream = httpRequest.GetRequestStream())
                                    //    {
                                    //        stream.Write(bytes, 0, bytes.Length);
                                    //        stream.Close();
                                    //    }
                                    //    using (HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse())
                                    //    {
                                    //        using (Stream stream = httpResponse.GetResponseStream())
                                    //        {
                                    //            var res = (new StreamReader(stream)).ReadToEnd();
                                    //            var data = (JObject)JsonConvert.DeserializeObject(res);

                                    //            string status = data["status"].Value<string>();
                                    //            smsException = status;

                                    //            Page.Response.Write("<script>console.log('OTP Suss');</script>");



                                    //        }
                                    //    }
                                    //}
                                    ////**************************************************************************************************************
                                    //#endregion
                                    SessionManager.GetInstance.Users = Result.Entity;
                                    lblOTPMobile.Text = Result.Entity.MobileNumber;
                                    ModalOTP.Show();

                                }
                            }
                            else
                            {

                                #region--> New API
                                //*************************---New API Integration---------- ****************************************************

                                //----------------------------------------- Latest Code --------------------------------------
                                var getSMSCred = await GetAccessToken();
                                Page.Response.Write("<script>console.log(' Call For OTP ');</script>");
                                string smsException = string.Empty;

                                string dyna_otp = Generatenumber();
                                if (!string.IsNullOrEmpty(getSMSCred.SenderID) && !string.IsNullOrEmpty(getSMSCred.AccessToken))
                                {
                                    List<string> MobileNumber = new List<string>();
                                    MobileNumber.Add(Result.Entity.MobileNumber);
                                    var Body = new
                                    {
                                        //service_type = "bulk_sms",
                                        //recipient_numbers_type = "single_numbers",
                                        //phone_numbers = MobileNumber.ToArray(),
                                        //content = "JepcoPortal Send : " + dyna_otp,
                                        //sender_id = "SENDER"

                                        service_type = "bulk_sms",
                                        recipient_numbers_type = "single_numbers",
                                        phone_numbers = MobileNumber.ToArray(),
                                        // content = "JepcoPortal Send : " + dyna_otp,
                                        content = "اهلا وسهلا بكم في البوابة الالكترونية لشركة الكهرباء رقم التعريف الخاص بك هو " + dyna_otp,
                                        sender_id = "JEPCO"

                                    };
                                    Page.Response.Write("<script>console.log('Mobile No : " + Result.Entity.MobileNumber + "');</script>");
                                    string inputJson = (new JavaScriptSerializer()).Serialize(Body);
                                    HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(new Uri(ConfigurationManager.AppSettings["SMSURL"].ToString()));
                                    httpRequest.ContentType = "application/json";
                                    httpRequest.Method = "POST";
                                    httpRequest.Headers.Add("integration_token", getSMSCred.AccessToken);

                                    byte[] bytes = Encoding.UTF8.GetBytes(inputJson);
                                    using (Stream stream = httpRequest.GetRequestStream())
                                    {
                                        stream.Write(bytes, 0, bytes.Length);
                                        stream.Close();
                                    }
                                    using (HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse())
                                    {
                                        using (Stream stream = httpResponse.GetResponseStream())
                                        {
                                            var res = (new StreamReader(stream)).ReadToEnd();
                                            var data = (JObject)JsonConvert.DeserializeObject(res);

                                            string status = data["status"].Value<string>();
                                            smsException = status;

                                            Page.Response.Write("<script>console.log('OTP Suss');</script>");

                                            try
                                            {
                                                MobileRegistationEntity MemberOTPEntity = new MobileRegistationEntity();

                                                MemberOTPEntity.ServiceUserID = UserId;
                                                MemberOTPEntity.MobileNumber = Result.Entity.MobileNumber;
                                                MemberOTPEntity.OTP = dyna_otp;
                                                MemberOTPEntity.IsVerify = false;
                                                MemberOTPEntity.AddDate = DateTime.Now;
                                                MemberOTPEntity.VerifyDate = DateTime.Now;

                                                var MemberOTPResult = await MobileRegistationDomain.Insert(MemberOTPEntity);

                                            }
                                            catch { }

                                        }
                                    }
                                }
                                //**************************************************************************************************************
                                #endregion
                                SessionManager.GetInstance.Users = Result.Entity;
                                lblOTPMobile.Text = Result.Entity.MobileNumber;
                                ModalOTP.Show();
                            }
                        }
                        else
                        {
                            SessionManager.GetInstance.Users = Result.Entity;
                            lblOTPMobile.Text = Result.Entity.MobileNumber;
                            ModalOTP.Show();
                        }
 
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Denied", "alert('Invalid Username Or Password');", true);
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Denied", "alert('Invalid Username Or Password');", true);
                }

            }
            else
            {
                
                if (_isValEmail)
                {
                    txtEmail.Style.Add("border", "none");
                }
                else
                {
                    txtEmail.Style.Add("border", "1px solid red");
                }
                lnkSubmitFrm.Focus();
            }

           
          
        }
        catch
        {
        }
    }

    protected void lnkClear_Click(object sender, EventArgs e)
    {

    }

   

    protected void btn_ok_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/LoginPage/Registration.aspx", false);
    }

    protected void FillFooterNavigation()
    {
        try
        {
            ResultList<FooterNavigationEntity> Result = new ResultList<FooterNavigationEntity>();
            Result = FooterNavigationDomain.GetFooterAllWithoutAsync();
            if (Result.Status == ErrorEnums.Success)
            {
                long _parentID = 0;

                Result.List = Result.List.Where(s => s.ParentID == _parentID && s.IsDeleted == false && s.IsPublished == true && s.LanguageID == Convert.ToInt32(Session["CurrentLanguage"]) && s.PublishDate <= currentDate).OrderBy(s => s.MenuOrder).Take(4).ToList();

                lstFooterNav.DataSource = Result.List.ToList();
                lstFooterNav.DataBind();
            }
        }
        catch (Exception e)
        {
        }
    }

    //protected async void FillLink()
    //{
    //    try
    //    {
    //        ResultList<PluginBannerEntity> res = new ResultList<PluginBannerEntity>();
    //        res = await PluginBannerDomain.GetPluginBannerAll();

    //        if (res.Status == ErrorEnums.Success)
    //        {



    //            var abcd = res.List.Where(s => !s.IsDeleted && s.IsPublished && s.PublishDate.Date <= currentDate.Date && s.CategoryID == 4 && s.LanguageID == Convert.ToInt32(Session["CurrentLanguage"])).OrderBy(s => s.BannerOrder).Take(1).ToList();
    //            string abcdstring = abcd.FirstOrDefault().Title.ToString();
    //            string abcdstring2 = abcd.FirstOrDefault().Link.ToString();
    //            //linklbl.Text = abcdstring.ToString();
    //            //lnk1.NavigateUrl = abcdstring2;


    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //    }
    //}


    public async Task<GetSMSCred> GetAccessToken()
    {
        GetSMSCred sMSCred = new GetSMSCred();
        try
        {
            var httpClient = new HttpClient();
            System.Net.ServicePointManager.SecurityProtocol |= System.Net.SecurityProtocolType.Tls12;
            var request = new HttpRequestMessage(HttpMethod.Post, ConfigurationManager.AppSettings["TokenURL"].ToString());

            string UserName = ConfigurationManager.AppSettings["SMSUName"].ToString();
            string Password = ConfigurationManager.AppSettings["SMSPWD"].ToString();

            request.Headers.Add("username", UserName);
            request.Headers.Add("password", Password);

            HttpResponseMessage response = await httpClient.SendAsync(request).ConfigureAwait(false);

            string json = await response.Content.ReadAsStringAsync();
            var serializer = new JavaScriptSerializer();
            dynamic item = serializer.Deserialize<object>(json);
            sMSCred.AccessToken = Convert.ToString(item["result"]["integration_token"]);
            sMSCred.SenderID = Convert.ToString(item["result"]["accountSid"]);
        }
        catch
        {
        }
        return sMSCred;
    }

    public class GetSMSCred
    {
        public string AccessToken { get; set; }
        public string SenderID { get; set; }
    }

    public static string Generatenumber()
    {
        var chars = "0123456789";
        var stringChars = new char[6];
        var random = new Random();
        for (int i = 0; i < stringChars.Length; i++)
        {
            stringChars[i] = chars[random.Next(chars.Length)];
        }
        var finalString = new String(stringChars);
        return finalString;
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        string OTp = txtOPT.Text;


        long UserId = SessionManager.GetInstance.Users.ID;


        ResultEntity<MobileRegistationEntity> MobileRegiEntity = new ResultEntity<MobileRegistationEntity>();
        MobileRegiEntity = MobileRegistationDomain.GetByIDNotAsync(UserId);
        if (MobileRegiEntity.Status == ErrorEnums.Success)
        {

            if (MobileRegiEntity.Entity.OTP == OTp)
            {
                MobileRegistationEntity MemberOTPEntity = new MobileRegistationEntity();

                MemberOTPEntity.RegistationID = MobileRegiEntity.Entity.RegistationID;
                MemberOTPEntity.ServiceUserID = MobileRegiEntity.Entity.ServiceUserID;
                MemberOTPEntity.MobileNumber = MobileRegiEntity.Entity.MobileNumber;
                MemberOTPEntity.OTP = MobileRegiEntity.Entity.OTP;
                MemberOTPEntity.IsVerify = true;


                var MemberOTPResult = MobileRegistationDomain.UpdateNotAsync(MemberOTPEntity);
                if (MemberOTPResult.Status == ErrorEnums.Success)
                {

                    Response.Redirect("/ar/Home", false);
                }
                else
                {
                    string MobileNo = SessionManager.GetInstance.Users.MobileNumber;
                    lblOTPMobile.Text = MobileNo;
                    ModalOTP.Show();
                }
            }
            else
            {
                string MobileNo = SessionManager.GetInstance.Users.MobileNumber;
                lblOTPMobile.Text = MobileNo;
                ModalOTP.Show();
                //lblErroreOTP.Visible = true;
                //FillServiceUser();
            }

        }
    }
}