﻿using HtmlAgilityPack;
using SiteWare.Domain.Domains;
using SiteWare.Entity.Common.Entities;
using SiteWare.Entity.Common.Enums;
using SiteWare.Entity.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class Controls_MessagesAndNotificationsList : System.Web.UI.UserControl
{
    DataPager pager1;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {

                string ServeceUserType = SessionManager.GetInstance.Users.UserType;
                if (ServeceUserType != "2")
                {
                    FillUser();
                    //Response.Redirect("~/Default.aspx", false);
                }
                else
                {
                     FillCompain();
                    
                }
            }
            //For Pagination 
            //pager1 = lstCompanyDevice.FindControl("DataPager1") as DataPager;
            //if (pager1 != null)
            //{
            //    pager1.PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
            //}
        }
        catch
        {
        }
    }

    protected void FillCompain()
    {
        try
        {
            try
            {
                long ServiceUserID = SessionManager.GetInstance.Users.ID;


                long CompanyId = 0;
                ResultEntity<Plugin_RenwabaleEnergyCompanyEntity> Result = new ResultEntity<Plugin_RenwabaleEnergyCompanyEntity>();

                Result = Plugin_RenwabaleEnergyCompanyDomain.GetByServiceUserIDNotAsync(ServiceUserID);
                if (Result.Status == ErrorEnums.Success)
                {

                   CompanyId = Result.Entity.RenwabaleEnergyCompanyID;
                    
                }




                ResultList<MessagesAndNotificationsEntity> res = new ResultList<MessagesAndNotificationsEntity>();
                res = MessagesAndNotificationsDomain.GetAllNotAsync();
                if (res.Status == ErrorEnums.Success)
                {

                    lstNotificationDevice.DataSource = res.List.Where(s => !s.IsDeleted && s.IsPublished && s.LanguageID == Convert.ToInt32(Session["CurrentLanguage"]) && s.MsgToUserID == CompanyId).ToList();
                    lstNotificationDevice.DataBind();

                    hdnCountRecord.Value = lstNotificationDevice.Items.Count.ToString();

                    //int Complaincout = lstCompanyDevice.Items.Count();
                    //lblTotalCount.Text = Complaincout.ToString();


                    //var AppoverCount = res.List.Where(s => !s.IsDeleted && s.IsPublished && s.LanguageID == Convert.ToInt32(Session["CurrentLanguage"]) && s.AddUser == ServiceUserID.ToString() && s.Status == "1").ToList();
                    //int Appover = AppoverCount.Count();
                    //lblAppoverCount.Text = Appover.ToString();

                    //var ReversingCount = res.List.Where(s => !s.IsDeleted && s.IsPublished && s.LanguageID == Convert.ToInt32(Session["CurrentLanguage"]) && s.AddUser == ServiceUserID.ToString() && s.Status == "2").ToList();
                    //int Reversing = AppoverCount.Count();
                    //lblReversingCount.Text = Reversing.ToString();


                }

            }
            catch (Exception ex)
            {
            }




        }
        catch (Exception ex)
        {
        }
    }

    int countLoop = 0;
    protected void lstNotificationDevice_ItemDataBound(object sender, ListViewItemEventArgs e)
    {
        try
        {
            if (e.Item.ItemType == ListViewItemType.DataItem)
            {

                HiddenField hdnMsgFromUserID = (HiddenField)e.Item.FindControl("hdnMsgFromUserID");
                Label lblUserName = (Label)e.Item.FindControl("lblUserName");
                
                
                ResultEntity<Plugin_ServiceUserEntity> ServiceUserEntity = new ResultEntity<Plugin_ServiceUserEntity>();
                ServiceUserEntity = Plugin_ServiceUserDomain.GetByIDNotAsync(Convert.ToInt64(hdnMsgFromUserID.Value));
                if(ServiceUserEntity.Status == ErrorEnums.Success)
                {
                    lblUserName.Text = ServiceUserEntity.Entity.FirstName + " "  + ServiceUserEntity.Entity.SecondName + " " + ServiceUserEntity.Entity.FamilyName ;
                }

                Label lblPublishDate = (Label)e.Item.FindControl("lblPublishDate");
                lblPublishDate.Text = Convert.ToDateTime(lblPublishDate.Text).ToString("dd-MM-yyyy");

                Label lblMsg = (Label)e.Item.FindControl("lblMsg");
                HiddenField hdnNotificationID = (HiddenField)e.Item.FindControl("hdnNotificationID");                
                HyperLink lnkNews = (HyperLink)e.Item.FindControl("lnkNews");
                
                string lang = string.Empty;
                lang = "/ar";
               

                string title = Regex.Replace(lblMsg.Text, @"[\\:/*#.]+", string.Empty);
                int ID = Convert.ToInt32(hdnNotificationID.Value.ToString());
                lnkNews.NavigateUrl = lang + "/NotificationAndMessagePage/" + title.Trim() + "/" + ID.ToString();

                countLoop++;

            }
        }
        catch (Exception ex)
        {
        }
    }

    protected void lstNewsRow_PagePropertiesChanging(object sender, PagePropertiesChangingEventArgs e)
    {
        try
        {
            DataPager pager1;
            pager1 = lstNotificationDevice.FindControl("DataPager1") as DataPager;
            (pager1).SetPageProperties(e.StartRowIndex, e.MaximumRows, false);
            this.FillCompain();
            //panelNews.Focus();
        }
        catch (Exception ex)
        {

        }
    }

    protected void Unnamed_Click(object sender, EventArgs e)
    {
        foreach (ListViewItem item in lstNotificationDevice.Items)
        {
            CheckBox CBID = ((CheckBox)item.FindControl("CBID"));
            if (CBID.Checked)
            {
                HiddenField hdnNotificationID = ((HiddenField)item.FindControl("hdnNotificationID"));

                long NotificationID = Convert.ToInt64(hdnNotificationID.Value);

                MessagesAndNotificationsEntity MSEntity = new MessagesAndNotificationsEntity();
                MSEntity.NotificationID = NotificationID;

                var deleteRecord = MessagesAndNotificationsDomain.DeleteNotAsync(MSEntity);
                if (deleteRecord.Status == ErrorEnums.Success)
                {
                    // mpeSuccess.Show();
                }



            }
        }

        FillCompain();
    }

    protected void FillUser()
    {
        try
        {
           




        }
        catch (Exception ex)
        {
        }
    }
}