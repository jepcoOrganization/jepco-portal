﻿using HtmlAgilityPack;
using SiteWare.Domain.Domains;
using SiteWare.Entity.Common.Entities;
using SiteWare.Entity.Common.Enums;
using SiteWare.Entity.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class Controls_RenewableEnergyUserRequestsList : System.Web.UI.UserControl
{
    DataPager pager1;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {

                string ServeceUserType = SessionManager.GetInstance.Users.UserType;
                if (ServeceUserType != "2")
                {
                    FillUserRequst();
                    
                }
                else
                {
                    Response.Redirect("~/Default.aspx", false);
                }

            }

            //For Pagination 
            pager1 = lstUserRequstdevice.FindControl("DataPager1") as DataPager;

            if (pager1 != null)
            {
                pager1.PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"]);
            }

        }
        catch
        {
        }
    }

    protected void FillUserRequst()
    {
        try
        {
            long ServiceUserID = SessionManager.GetInstance.Users.ID;

            ResultList<RenewableEnergyUserRequestsEntity> res = new ResultList<RenewableEnergyUserRequestsEntity>();
            res = RenewableEnergyUserRequestsDomain.GetAllNotAsync();
            if (res.Status == ErrorEnums.Success)
            {

                lstUserRequstdevice.DataSource = res.List.Where(s => !s.IsDeleted && s.IsPublished && s.LanguageID == Convert.ToInt32(Session["CurrentLanguage"]) && s.AddUser == ServiceUserID.ToString()).OrderByDescending(s => s.RenwableEnergyID).ToList();
                lstUserRequstdevice.DataBind();

                //int Complaincout = lstUserRequstdevice.Items.Count();
                //lblTotalCount.Text = Complaincout.ToString();


                //var AppoverCount = res.List.Where(s => !s.IsDeleted && s.IsPublished && s.LanguageID == Convert.ToInt32(Session["CurrentLanguage"]) && s.AddUser == ServiceUserID.ToString()).ToList();
                //int Appover = AppoverCount.Count();
                //lblAppoverCount.Text = Appover.ToString();

                var ReversingCount = res.List.Where(s => !s.IsDeleted && s.IsPublished && s.LanguageID == Convert.ToInt32(Session["CurrentLanguage"]) && s.AddUser == ServiceUserID.ToString() && s.CompanyAcceptedStatus == true).ToList();
                int Reversing = ReversingCount.Count();
                lblReversingCount.Text = Reversing.ToString();


                lblAppoverCount.Text = "0";
               

            }

        }
        catch (Exception ex)
        {
        }
    }

    protected void lstUserRequstdevice_itemdatabound(object sender, ListViewItemEventArgs e)
    {
        try
        {
            if (e.Item.ItemType == ListViewItemType.DataItem)
            {

                Label lblPublishDate = (Label)e.Item.FindControl("lblPublishDate");
                lblPublishDate.Text = Convert.ToDateTime(lblPublishDate.Text).ToString("dd-MM-yyyy");

                Label lblCompany = (Label)e.Item.FindControl("lblCompany");
                Label lblTelePhone = (Label)e.Item.FindControl("lblTelePhone");
                

                ResultEntity<Plugin_RenwabaleEnergyCompanyEntity> RenwabaleEnergyCompanyEntity = new ResultEntity<Plugin_RenwabaleEnergyCompanyEntity>();
                RenwabaleEnergyCompanyEntity = Plugin_RenwabaleEnergyCompanyDomain.GetByIDNotAsync(Convert.ToInt32(lblCompany.Text));
                if (RenwabaleEnergyCompanyEntity.Status == ErrorEnums.Success)
                {
                    lblCompany.Text = RenwabaleEnergyCompanyEntity.Entity.CompanyName;
                    lblTelePhone.Text = RenwabaleEnergyCompanyEntity.Entity.MobileNumber;
                }

            }
        }
        catch (Exception ex)
        {
        }
    }

    protected void lstnewsrow_pagepropertieschanging(object sender, PagePropertiesChangingEventArgs e)
    {
        try 
        {
            DataPager pager1;
            pager1 = lstUserRequstdevice.FindControl("DataPager1") as DataPager;
            (pager1).SetPageProperties(e.StartRowIndex, e.MaximumRows, false);
            this.FillUserRequst();
            //panelNews.Focus();
        }
        catch (Exception ex)
        {

        }
    }
}